package com.example.pokemonapp.util;

public class Constants {
    final public static String BASE_URL = "https://pokeapi.co/api/v2/";
}
